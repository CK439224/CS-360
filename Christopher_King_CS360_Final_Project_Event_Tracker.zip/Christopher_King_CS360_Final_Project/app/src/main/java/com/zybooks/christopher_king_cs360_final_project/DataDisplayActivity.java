package com.zybooks.christopher_king_cs360_final_project;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DataDisplayActivity extends AppCompatActivity implements EventsAdapter.OnEventDeleteListener {

    private static final int PERMISSION_REQUEST_SEND_SMS = 123;
    private static final int PERMISSION_REQUEST_READ_PHONE_STATE = 124;

    private EventsAdapter eventsAdapter;
    private EventViewModel eventViewModel;

    private TextInputLayout textInputLayoutDate;
    private EditText editTextDate;
    private EditText editTextTime;
    private EditText editTextPhoneNumber; // New field
    private Spinner spinnerNotificationTime;
    private Calendar calendar;

    // Class fields to store event details
    private String description;
    private String date;
    private String time;
    private String notificationTime;
    private String phoneNumber; // New field

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize ViewModel using ViewModelProvider with factory
        EventViewModelFactory factory = new EventViewModelFactory(getApplication());
        eventViewModel = new ViewModelProvider(this, factory).get(EventViewModel.class);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        Button addDataButton = findViewById(R.id.add_data_button);

        eventsAdapter = new EventsAdapter(this, this); // Pass this as listener
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(eventsAdapter);

        // Observe changes in the events list from ViewModel
        eventViewModel.getEvents().observe(this, events -> {
            eventsAdapter.setEvents(events); // Update RecyclerView with new events
        });

        addDataButton.setOnClickListener(v -> showAddEventDialog());
    }

    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_event, null);
        builder.setView(dialogView);

        EditText editTextDescription = dialogView.findViewById(R.id.editTextDescription);
        editTextDate = dialogView.findViewById(R.id.editTextDate);
        editTextTime = dialogView.findViewById(R.id.editTextTime);
        editTextPhoneNumber = dialogView.findViewById(R.id.editTextPhoneNumber); // New field
        spinnerNotificationTime = dialogView.findViewById(R.id.spinnerNotificationTime);
        Button buttonAddEvent = dialogView.findViewById(R.id.buttonAddEvent);

        // Initialize calendar instance
        calendar = Calendar.getInstance();

        // Set click listener for date field to show date picker
        editTextDate.setOnClickListener(v -> showDatePicker());

        // Set click listener for time field to show time picker
        editTextTime.setOnClickListener(v -> showTimePicker());

        AlertDialog dialog = builder.create();

        buttonAddEvent.setOnClickListener(v -> {
            description = editTextDescription.getText().toString();
            date = editTextDate.getText().toString();
            time = editTextTime.getText().toString();
            notificationTime = spinnerNotificationTime.getSelectedItem().toString();
            phoneNumber = editTextPhoneNumber.getText().toString(); // New field

            if (!description.isEmpty() && !date.isEmpty() && !time.isEmpty() && !phoneNumber.isEmpty()) {
                Event newEvent = new Event(description, date, time);
                eventViewModel.addEvent(newEvent); // Add event via ViewModel

                checkForSmsPermission(description, date, time, notificationTime, phoneNumber);

                dialog.dismiss();
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void showDatePicker() {
        // Create MaterialDatePicker instance
        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Date")
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .build();

        // Set listener to update EditText when date is selected
        datePicker.addOnPositiveButtonClickListener(selection -> {
            calendar.setTimeInMillis(selection);
            String selectedDate = new SimpleDateFormat("MM/dd/yyyy", Locale.US).format(calendar.getTime());
            editTextDate.setText(selectedDate);
        });

        // Show the date picker dialog
        datePicker.show(getSupportFragmentManager(), "DATE_PICKER");
    }

    private void showTimePicker() {
        // Create TimePickerDialog instance
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view, selectedHour, selectedMinute) -> {
                    // Format the selected time into a string
                    String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
                    editTextTime.setText(formattedTime);
                }, hour, minute, true); // true for 24 hour format

        // Show the time picker dialog
        timePickerDialog.show();
    }

    private void checkForSmsPermission(String description, String date, String time, String notificationTime, String phoneNumber) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
        } else {
            scheduleSmsNotification(description, date, time, notificationTime, phoneNumber);
        }
    }

    private void scheduleSmsNotification(String description, String date, String time, String notificationTime, String phoneNumber) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.getDefault());
        try {
            Date eventDate = sdf.parse(date + " " + time);
            if (eventDate == null) {
                Toast.makeText(this, "Invalid date/time format", Toast.LENGTH_SHORT).show();
                return;
            }

            Calendar notificationCalendar = Calendar.getInstance();
            notificationCalendar.setTime(eventDate);
            adjustNotificationTime(notificationCalendar, notificationTime);

            Intent intent = new Intent(this, SmsBroadcastReceiver.class);
            intent.putExtra("phoneNumber", phoneNumber);
            intent.putExtra("message", description);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, notificationCalendar.getTimeInMillis(), pendingIntent);

            Toast.makeText(this, "Notification scheduled", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to schedule notification", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void adjustNotificationTime(Calendar calendar, String notificationTime) {
        switch (notificationTime) {
            case "5 minutes before":
                calendar.add(Calendar.MINUTE, -5);
                break;
            case "10 minutes before":
                calendar.add(Calendar.MINUTE, -10);
                break;
            case "30 minutes before":
                calendar.add(Calendar.MINUTE, -30);
                break;
            case "1 hour before":
                calendar.add(Calendar.HOUR, -1);
                break;
            case "1 day before":
                calendar.add(Calendar.DAY_OF_YEAR, -1);
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                scheduleSmsNotification(description, date, time, notificationTime, phoneNumber);
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == PERMISSION_REQUEST_READ_PHONE_STATE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Handle permission grant for READ_PHONE_STATE if needed
            } else {
                Toast.makeText(this, "READ_PHONE_STATE permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onEventDelete(Event event) {
        eventViewModel.removeEvent(event);
    }
}

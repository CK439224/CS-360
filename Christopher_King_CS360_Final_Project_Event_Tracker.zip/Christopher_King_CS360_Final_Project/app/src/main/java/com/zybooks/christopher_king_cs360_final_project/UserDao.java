package com.zybooks.christopher_king_cs360_final_project;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username AND password = :password")
    User getUser(String username, String password);

    @Insert
    void insertUser(User user);

    @Query("SELECT COUNT(*) FROM users WHERE username = :username")
    int getUserCount(String username);
}

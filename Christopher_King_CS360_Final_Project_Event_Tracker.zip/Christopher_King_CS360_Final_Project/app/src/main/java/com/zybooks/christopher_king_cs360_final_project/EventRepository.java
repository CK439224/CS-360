package com.zybooks.christopher_king_cs360_final_project;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.Executors;

public class EventRepository {
    private EventDao eventDao;
    private LiveData<List<Event>> allEvents;

    public EventRepository(Application application) {
        EventDatabase database = EventDatabase.getInstance(application);
        eventDao = database.eventDao();
        allEvents = eventDao.getAllEvents();
    }

    public LiveData<List<Event>> getAllEvents() {
        return allEvents;
    }

    public void insert(Event event) {
        // Execute the insertion operation on a background thread
        Executors.newSingleThreadExecutor().execute(() -> {
            eventDao.insert(event);
        });
    }


    public void delete(Event event) {
        // Execute the deletion operation on a background thread
        Executors.newSingleThreadExecutor().execute(() -> {
            eventDao.delete(event);
        });
    }


    public EventDao getEventDao() {
        return eventDao;
    }
}

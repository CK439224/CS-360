package com.zybooks.christopher_king_cs360_final_project;

import android.app.Application;

import androidx.room.Room;

public class MyApplication extends Application {

    private EventDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();

        // Initialize Room database instance
        db = Room.databaseBuilder(getApplicationContext(),
                        EventDatabase.class, "events-db")
                .build();
    }

    public EventDatabase getDatabase() {
        return db;
    }
}

package com.zybooks.christopher_king_cs360_final_project;
import android.app.Application;
import com.zybooks.christopher_king_cs360_final_project.EventRepository;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import java.util.List;

public class EventViewModel extends ViewModel {

    private EventRepository eventRepository;
    private LiveData<List<Event>> eventsLiveData;

    public EventViewModel(@NonNull Application application) {
        eventRepository = new EventRepository(application);
        eventsLiveData = eventRepository.getAllEvents();
    }

    public LiveData<List<Event>> getEvents() {
        return eventsLiveData;
    }

    public void addEvent(Event event) {
        eventRepository.insert(event);
    }

    public void removeEvent(Event event) {
        eventRepository.delete(event);
    }

    public EventDao getEventDao() {
        return eventRepository.getEventDao();
    }
}

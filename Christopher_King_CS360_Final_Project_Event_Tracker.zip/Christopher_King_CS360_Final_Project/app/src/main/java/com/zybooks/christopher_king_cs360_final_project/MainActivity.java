package com.zybooks.christopher_king_cs360_final_project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import android.app.Application;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class MainActivity extends AppCompatActivity {


    private EditText usernameEditText;
    private EditText passwordEditText;
    private UserDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.editTextText);
        passwordEditText = findViewById(R.id.editTextTextPassword);

        db = Room.databaseBuilder(getApplicationContext(), UserDatabase.class, "user-database").allowMainThreadQueries().build();

        findViewById(R.id.login_button).setOnClickListener(v -> loginUser());
        findViewById(R.id.create_account_button).setOnClickListener(v -> registerUser());
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show();
            return;  // Exit the method if username is empty
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Please enter a password", Toast.LENGTH_SHORT).show();
            return;  // Exit the method if password is empty
        }

        User user = db.userDao().getUser(username, password);
        if (user != null) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            // Proceed to DataDisplayActivity
            Intent intent = new Intent(this, DataDisplayActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerUser() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Check if username exists
        int userCount = db.userDao().getUserCount(username);

        if (userCount > 0) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        } else {
            User user = new User();
            user.username = username;
            user.password = password;

            db.userDao().insertUser(user);
            Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToDataDisplayActivity() {
        Intent intent = new Intent(this, DataDisplayActivity.class);
        startActivity(intent);
    }
}


//Test for activity_data_display
    /*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_data_display);

        ;
    }*/


    //Test for activity_sms_notification
    /*
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_sms_notification);

        ;
    }*/
